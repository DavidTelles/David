function volume(base, largura, altura) {
    return base * altura * largura
}

console.log(volume(10, 10, 10))